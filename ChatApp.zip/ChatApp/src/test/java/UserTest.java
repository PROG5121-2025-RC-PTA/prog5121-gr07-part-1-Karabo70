import model.User;
import org.junit.jupiter.api.Test;
public class UserTest { 
    User user;

    public UserTest() {
        this.user = new User();
    }

    @Test 
    public void testCheckUserName_Valid() { 
        user.setUsername("ky_1"); 
        assertTrue(user.checkUserName()); 
    } 

    @Test 
    public void testCheckUserName_Invalid() { 
        user.setUsername("kyle!!!!!!!"); 
        assertFalse(user.checkUserName()); 
    } 
    
    @Test 
    public void testCheckPasswordComplexity_Valid() { 
        user.setPassword("Ch&&sec@ke99!"); 
        assertTrue(user.checkPasswordComplexity()); 
    } 

    @Test 
    public void testCheckPasswordComplexity_Invalid() { 
        user.setPassword("password"); 
        assertFalse(user.checkPasswordComplexity()); 
    } 

    @Test 
    public void testCheckCellPhoneNumber_Valid() { 
        user.setCellPhone("+27838968976"); 
        assertTrue(user.checkCellPhoneNumber()); 
    } 
    
    @Test 
    public void testCheckCellPhoneNumber_Invalid() { 
        user.setCellPhone("08966553"); 
        assertFalse(user.checkCellPhoneNumber()); 
    } 

    @Test 
    public void testLoginUser_Successful() { 
        user.setUsername("ky_1"); 
        user.setPassword("Ch&&sec@ke99!"); 
        user.registerUser();  // Register the user first 
        assertTrue(user.loginUser("ky_1", "Ch&&sec@ke99!")); 
    } 

    @Test 
    public void testLoginUser_Failed() { 
        user.setUsername("ky_1"); 
        user.setPassword("Ch&&sec@ke99!"); 
        user.registerUser(); 
        assertFalse(user.loginUser("wrong_user", "wrong_pass")); 
    } 
} 