import model.Message; 
import model.User; 
import util.MessageUtils; 
import javax.swing.*; 
import java.util.ArrayList; 
import java.util.List; 
public class Main { 
    static List<Message> messages = new ArrayList<>(); 
    public static void main(String[] args) { 
        User user = new User("john_", "Password1!"); 
        String username = JOptionPane.showInputDialog("Enter Username:"); 
        String password = JOptionPane.showInputDialog("Enter Password:"); 
        if (!user.login(username, password)) { 
            JOptionPane.showMessageDialog(null, "Login Failed!"); 
            return; 
        } 
        
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat."); 
        int numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?")); 
        boolean running = true; 
        while (running) { 
            String menu = JOptionPane.showInputDialog("Choose:\n1) Send Messages\n2) View Messages\n3) Quit"); 
            switch (menu) { 
                case "1": 
                    for (int i = 0; i < numMessages; i++) { 
                        String recipient = JOptionPane.showInputDialog("Enter recipient number (+27...):"); 
                        String msgText = JOptionPane.showInputDialog("Enter message:"); 
                        Message msg = new Message(msgText, recipient); 
                        if (!msg.validateMessageLength()) { 
                            JOptionPane.showMessageDialog(null, "Message exceeds 250 characters."); 
                            continue; 
                        } 

                        if (!msg.checkRecipientCell()) { 
                            JOptionPane.showMessageDialog(null, "Invalid phone number format."); 
                            continue;
                        } 

                        String result = msg.sendMessage(); 
                        JOptionPane.showMessageDialog(null, result); 
                        messages.add(msg); 
                    } 

                    break; 
                case "2": 
                    JOptionPane.showMessageDialog(null, "Coming Soon."); 
                    break; 
                case "3": 
                    running = false; 
                    break; 
            } 
        } 

        StringBuilder summary = new StringBuilder("Messages Sent:\n"); 
        int totalSent = 0; 
        for (Message msg : messages) { 
            if (msg.isSent()) { 
                summary.append(msg.printMessage()).append("\n\n"); 
                totalSent++; 
            } 
        } 

        JOptionPane.showMessageDialog(null, summary + "\nTotal messages sent: " + totalSent); 
        MessageUtils.storeMessages(messages); 
    } 
} 
