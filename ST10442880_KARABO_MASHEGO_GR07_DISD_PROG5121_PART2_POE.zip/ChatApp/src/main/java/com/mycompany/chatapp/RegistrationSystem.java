package com.mycompany.chatapp;
import java.util.Scanner; 
import java.util.regex.*; 
public class RegistrationSystem { 
    private static String storedUsername = ""; 
    private static String storedPassword = ""; 
    private static String storedCellNumber = ""; 
    private static String firstName = ""; 
    private static String lastName = ""; 
    public static boolean checkUserName(String username) { 
        return username.contains("_") && username.length() <= 5; 

    } 
    public static boolean checkPasswordComplexity(String password) { 
        return password.length() >= 8 && 
               password.matches(".*[A-Z].*") && 
               password.matches(".*[0-9].*") && 
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*"); 
    } 
    public static boolean checkCellPhoneNumber(String cell) { 
        return cell.matches("^\\+27[0-9]{9}$"); 
    } 

    public static String registerUser(String username, String password, String cell, String fName, String lName) { 
        if (!checkUserName(username)) { 
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length."; 
        } 
        if (!checkPasswordComplexity(password)) { 
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character."; 
        } 

        if (!checkCellPhoneNumber(cell)) { 
            return "Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again."; 
        } 
        storedUsername = username; 
        storedPassword = password; 
        storedCellNumber = cell; 
        firstName = fName; 
        lastName = lName; 
        return "Registration successful!"; 
    } 
    public static boolean loginUser(String username, String password) { 
        return username.equals(storedUsername) && password.equals(storedPassword); 
    } 

    public static String returnLoginStatus(String username, String password) { 
        if (loginUser(username, password)) { 
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again."; 
        } else { 

            return "Username or password incorrect, please try again."; 
        }
    } 
    
    // Main method for demonstration 
    public static void main(String[] args) { 
        Scanner scanner = new Scanner(System.in); 
        System.out.println("Register your account:"); 
        System.out.print("Enter first name: "); 
        String fName = scanner.nextLine(); 
        System.out.print("Enter last name: "); 
        String lName = scanner.nextLine(); 
        System.out.print("Enter username: "); 
        String username = scanner.nextLine(); 
        System.out.print("Enter password: "); 
        String password = scanner.nextLine(); 
        System.out.print("Enter cellphone number (+27...): "); 
        String cell = scanner.nextLine(); 
        String registrationResult = registerUser(username, password, cell, fName, lName); 
        System.out.println(registrationResult);
        
        if (registrationResult.equals("Registration successful!")) { 
            System.out.println("\nLogin to your account:"); 
            System.out.print("Enter username: "); 
            String loginUser = scanner.nextLine(); 
            System.out.print("Enter password: "); 
            String loginPass = scanner.nextLine(); 
            System.out.println(returnLoginStatus(loginUser, loginPass)); 
        } 
        scanner.close(); 
    } 
} 
