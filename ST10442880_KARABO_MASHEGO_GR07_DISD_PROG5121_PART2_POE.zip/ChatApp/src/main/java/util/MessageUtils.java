package util; 
import model.Message; 
import org.json.simple.JSONArray; 
import org.json.simple.JSONObject; 
import java.io.FileWriter; 
import java.io.IOException; 
import java.util.List; 
public class MessageUtils { 
    public static void storeMessages(List<Message> messages) { 
        JSONArray jsonArray = new JSONArray(); 
        for (Message msg : messages) { 
            JSONObject obj = new JSONObject(); 
            obj.put("messageId", msg.getMessageId()); 
            obj.put("recipient", msg.getRecipient()); 
            obj.put("message", msg.getMessage()); 
            obj.put("messageHash", msg.getMessageHash()); 
            obj.put("sent", msg.isSent()); 
            jsonArray.add(obj); 
        } 

        try (FileWriter file = new FileWriter("data/messages.json")) { 
            file.write(jsonArray.toJSONString()); 
            file.flush(); 
        } catch (IOException e) { 
            e.printStackTrace(); 
        } 
    } 
} 
