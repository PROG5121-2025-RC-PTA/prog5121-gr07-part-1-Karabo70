package model; 
import javax.swing.*; 
import java.util.UUID; 
public class Message { 
    private String messageId; 
    private String message; 
    private String recipient; 
    private String messageHash; 
    private boolean sent; 
    public Message(String message, String recipient) { 
        this.messageId = generateMessageId(); 
        this.message = message; 
        this.recipient = recipient; 
        this.messageHash = createMessageHash(); 
        this.sent = false; 
    } 

    public static String generateMessageId() { 
        return UUID.randomUUID().toString().substring(0, 10); 
    } 

    public boolean checkMessageId() { 
        return this.messageId.length() <= 10; 
    } 

    public boolean checkRecipientCell() { 
        return recipient.length() <= 13 && recipient.startsWith("+27"); 
    } 

    public boolean validateMessageLength() { 
        return message.length() <= 250; 
    } 

    public String createMessageHash() { 
        String[] words = message.split(" "); 
        String firstWord = words[0]; 
        String lastWord = words[words.length - 1]; 
        return messageId.substring(0, 2) + ":0:" + words.length + ":" + firstWord.toUpperCase() + lastWord.toUpperCase(); 
    } 
    
    public String sendMessage() { 
        int choice = JOptionPane.showOptionDialog(null, 
                "Choose option:", 
                "Send Message", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.INFORMATION_MESSAGE, 
                null, 
                new String[]{"Send", "Disregard", "Store"}, 
                null); 
        if (choice == 0) { 
            this.sent = true; 
            return "Message sent."; 
        } else if (choice == 1) { 
            return "Message disregarded."; 
        } else { 
            return "Message stored for later."; 
        } 
    } 

    public String printMessage() { 
        return "MessageID: " + messageId + 
               "\nHash: " + messageHash + 
               "\nRecipient: " + recipient + 
               "\nMessage: " + message; 
    } 

    public boolean isSent() { 
        return sent; 
    } 

    public String getMessageId() { 
        return messageId; 
    } 

    public String getMessageHash() { 
        return messageHash; 
    } 

    public String getRecipient() { 
        return recipient; 
    } 

    public String getMessage() { 
        return message; 
    } 
} 